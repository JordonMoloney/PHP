
<?php  require('includes/header.php'); 

//initialzing variables

$person_id = null;
$name = null;
$email = null;
$city = null;
$skills = null;

//check if we have a city id and that it is a number 
if(!empty($_GET['person_id']) && (is_numeric(($_GET[person_id])))){


//grab the city id
  $city_id = $_GET['person_id'];

  //connect to the db
  require('includes/db.php');

  //set up the query
  $sql = "SELECT * FROM syntax WHERE person_id = :person_id;";

  //prepare 
  $cmd = $connn->prepare($sql);

  //bindParam

  $cmd->bindParam(':person_id', $city_id);

  //execute
  $cmd->execute();

  //use fetchAll to store
  $information = $cmd->fetchAll();

  //loops through the array
  foreach($information as $info){
    $name = $info['name'];
    $email = $info['email'];
    $city = $info['city'];
    $skills = $info['skillsS'];
  }

  //close db connection
  $cmd->closeCursor();
}

?>
     <p> Please Fill In The Following Information</p>
      <form method="post" action="send-it.php">
        <div class="form-group">
          <input type="text" name="name" class="form-control" placeholder="What's Your Name" require value="<?php echo $name; ?>">
        </div>
        <br/>
        <div class="form-group">
          <input type="text" name="email" class="form-control" placeholder="What's Your Email?" require value="<?php echo $email; ?>">
        </div>
        <br/>
        <div class="form-group">
          <input type="text" name="city" class="form-control" placeholder="What's your current city?" require value="<?php echo $city; ?>">
        </div>
        <br/>
        <div class="form-group">
          <input type="text" name="skills" class="form-control" placeholder="What Are Your Best Skills?" require value="<?php echo $skills; ?>">
        </div>
        <br/>
          <!-- Hidden input for person_id -->
          <input type="hidden" name="person_id" value="<?php echo $person_id;?>" >
          <input id="submit" type="submit" name="submit" value="submit" class="btn btn-primary">
      </form>
    </div>
</main>
<?php require('includes/footer.php'); ?>

</body>
</html>