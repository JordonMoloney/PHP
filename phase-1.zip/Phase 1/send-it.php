    <?php require('includes/header.php');
    
    //add person_id incase we are editing 
    $person_id = null;
    $ok = true;

      // try {
        if(isset($_POST['submit'])){

        $person_id = filter_input(INPUT_POST, 'person_id');
        $name = filter_input(INPUT_POST, 'name');
        $email = filter_input(INPUT_POST, 'email');
        $city = filter_input(INPUT_POST, 'city');
        $skills = filter_input(INPUT_POST, 'skills');


        //form validation
        if(empty($name)){
          $ok = false;
          echo'<p> You must provide a name</p>';
        }

        if(empty($email) || $email === false){
          $ok = false;
          echo'<p> You must provide a valid email</p>';
        }

        if(empty($city)){
          $ok = false;
          echo'<p> You must provide a city name</p>';
        }

        if(empty($skills)){
          $ok = false;
          echo'<p> You must provide one or more skills</p>';
        }


        if(empty($city) || empty($name) || empty($email) || empty($email)){
         
          echo'<form action="index.php">
                <input type="submit" value="Return" />
              </form>';
        }

          if($ok){
        
       require('includes/db.php');
         
         if(!empty($person_id)){
            $sql = "UPDATE syntax SET (name = :name, email = :email, city = :city, skills = :skills) WHERE person_id = :person_id;";          
         } 
         else{
        $sql = "INSERT INTO syntax(name, email, city, skills) VALUES (:name, :email, :city, :skills)";
          }
        $cmd = $conn->prepare($sql); 
        
        $cmd->bindParam(':name', $name);
        $cmd->bindParam(':email', $email); 
        $cmd->bindParam(':city', $city); 
        $cmd->bindParam(':skills', $skills); 
          
         if(!empty($person_id)){
          $cmd->bindParam('person_id', $person_id);
         } 

        $cmd->execute(); 
          
        echo "<p> Thanks for your submission!</p>";
        
        echo "<a id='link' href='table.php'>View Entries</a><br/><br/>";

        echo'<form action="index.php">
                <input type="submit" value="Return"/>
              </form>';
          
        $cmd->closeCursor();  
        }
      }
    ?>
  
   
</main>
</body>
</html>