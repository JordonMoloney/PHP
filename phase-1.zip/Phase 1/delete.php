<?php
ob_start();

$person_id = $GET['person_id'];


require('includes/db.php');

$sql = "DELETE FROM syntax WHERE syntax.person_id = :person_id;";

$cmd = $conn->prepare($sql);



$cmd->bindParam(':person_id', $person_id);

$cmd->execute();

$conn = NULL;

header('location:table.php');


ob_flush();
?>















