<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>The Syntax WorkSpace</title>
<link rel="shortcut icon" href="images/logo.jpg" />

<link rel="stylesheet" href="main.css">
<!-- Latest compiled and minified JavaScript -->



<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>

<body>
  <main class="container">
  	    <div class="inner">

     <h1> Syntax WorkSpace</h1>