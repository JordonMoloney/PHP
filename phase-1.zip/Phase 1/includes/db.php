 <?php
 $conn = new PDO('mysql:host=127.0.0.1:54357; dbname=localdb', 'azure', '6#vWHD_$');
 ?>


