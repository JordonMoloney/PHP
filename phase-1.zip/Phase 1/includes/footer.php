
<footer>
    <p> Copyright <?php  echo(date("Y")) ?>. All rights reserved.</p>
 </footer>

 