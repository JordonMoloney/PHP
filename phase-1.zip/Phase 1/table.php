<?php require('includes/header.php');
ob_start();

try{
//Connect to the database
require('includes/db.php');	


//Build our query
$sql = "SELECT * FROM syntax;";


//prepare

$cmd = $conn->prepare($sql);

//execute
$cmd->execute();

//Use fetchAll to store the results

$table = $cmd->fetchAll();

echo'<table class="table">
		<thead>
			<th> Name </th>
			<th> Email </th>
			<th> City </th>
			<th> Skills </th>
			<th> Edit </th>
			<th> Delete </th>
		</thead>
	<tbody>'; 

//loop through the data and create a new table for each record

foreach($table as $item){
	echo '<tr><td>'.$item['name'].'</td>';
	echo '<td>'.$item['email'].'</td>';
	echo '<td>'.$item['city'].'</td>';
	echo '<td>'.$item['skills'].'</td>';
	echo '<td><a href="index.php?	person_id='.$item['person_id'].'"> Edit? </td>';
	echo '<td><a href="delete.php?person_id='.$item['person_id'].'"onclick= "returnconfirm (\'Are You Sure?\');"> Delete? </a></td></tr>';
}	



echo '</tbody></table>';

//close

echo "<p> Thank you for sharing </p>";

$cmd->closeCursor();
}

catch(PDOException $e){
	header('location:errpr.php');
	mail('jjmolone@lakeheadu.ca');

}


ob_flush();
require('includes/footer.php');

?>